package FinallProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MarketPlaceManager {
    private List<Product> products;
    private AuthenticationManager authManager;

    public MarketPlaceManager(AuthenticationManager authManager) {
        this.products = new ArrayList<>();
        this.authManager = authManager;
    }


    public void displayUserProducts() {
        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();
            List<Product> userProducts = currentUser.getProductsPosted();

            System.out.println("--- Your Products ---");
            for (Product product : userProducts) {
                if (!product.isSold()) {
                    System.out.println(product);
                }
            }
        } else {
            System.out.println("You need to sign in to view your products.");
        }
    }
    public void postProduct() {
        Scanner scanner = new Scanner(System.in);

        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();

            System.out.println("--- Post Product ---");
            System.out.print("Enter product title: ");
            String title = scanner.nextLine();
            System.out.print("Enter product description: ");
            String description = scanner.nextLine();
            System.out.print("Enter product price: ");
            double price = scanner.nextDouble();
            scanner.nextLine(); // Consume the newline character
            System.out.print("Enter product category (ELECTRONICS, BOOKS, CLOTHING): ");
            String categoryStr = scanner.nextLine().toUpperCase();
            Category category = Category.valueOf(categoryStr);

            Product newProduct = new Product(title, description, price, category, currentUser);
            currentUser.addPostedProduct(newProduct);
            products.add(newProduct);

            System.out.println("Product posted successfully.");
        } else {
            System.out.println("You need to sign in to post a product.");
        }
    }

    public void displayProductListings() {
        System.out.println("--- Product Listings ---");

        for (Product product : products) {
            if (!product.isSold()) {
                System.out.println("Title: " + product.getTitle());
                System.out.println("Description: " + product.getDescription());
                System.out.println("Price: $" + product.getPrice());
                System.out.println("Category: " + product.getCategory());
                System.out.println("Seller: " + product.getSeller().getUsername());
                System.out.println("-------------------------");
            }
        }
    }

    public void filterProductsByCategory() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter category to filter (ELECTRONICS, BOOKS, CLOTHING): ");
        String categoryStr = scanner.nextLine().toUpperCase();
        Category category = Category.valueOf(categoryStr);

        System.out.println("--- Product Listings in " + category + " ---");

        for (Product product : products) {
            if (!product.isSold() && product.getCategory() == category) {
                System.out.println("Title: " + product.getTitle());
                System.out.println("Description: " + product.getDescription());
                System.out.println("Price: $" + product.getPrice());
                System.out.println("Category: " + product.getCategory());
                System.out.println("Seller: " + product.getSeller().getUsername());
                System.out.println("-------------------------");
            }
        }
    }
    public void sellProduct() {
        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();
            List<Product> userProducts = currentUser.getProductsPosted();

            if (!userProducts.isEmpty()) {
                System.out.println("--- Your Products for Sale ---");
                for (int i = 0; i < userProducts.size(); i++) {
                    System.out.println((i + 1) + ". " + userProducts.get(i));
                }

                System.out.print("Enter the number of the product you want to sell: ");
                Scanner scanner = new Scanner(System.in);
                int productNumber = scanner.nextInt();

                if (productNumber >= 1 && productNumber <= userProducts.size()) {
                    Product selectedProduct = userProducts.get(productNumber - 1);

                    if (!selectedProduct.isSold()) {
                        selectedProduct.setSold(true);
                        System.out.println("Product sold successfully.");
                    } else {
                        System.out.println("Product is already sold.");
                    }
                } else {
                    System.out.println("Invalid product number.");
                }
            } else {
                System.out.println("You have no products for sale.");
            }
        } else {
            System.out.println("You need to sign in to sell a product.");
        }
    }

    public void buyProduct() {
        Scanner scanner = new Scanner(System.in);

        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();

            System.out.println("--- Buy Product ---");
            System.out.print("Enter the title of the product you want to buy: ");
            String productTitle = scanner.nextLine();

            for (Product product : products) {
                if (!product.isSold() && product.getTitle().equals(productTitle)) {
                    if (product.getSeller() != currentUser) {
                        // Perform the buy operation (e.g., update isSold flag, track the transaction, etc.)
                        product.setSold(true);
                        currentUser.addBoughtProduct(product);
                        System.out.println("Product purchased successfully.");
                    } else {
                        System.out.println("You cannot buy your own product.");
                    }
                    return;
                }
            }

            System.out.println("Product not found or already sold.");
        } else {
            System.out.println("You need to sign in to buy a product.");
        }
    }
    public void displaySoldProducts() {
        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();
            List<Product> userProducts = currentUser.getProductsPosted();

            System.out.println("--- Your Sold Products ---");
            boolean hasSoldProducts = false;
            for (Product product : userProducts) {
                if (product.isSold()) {
                    System.out.println(product);
                    hasSoldProducts = true;
                }
            }

            if (!hasSoldProducts) {
                System.out.println("You have not sold any products yet.");
            }
        } else {
            System.out.println("You need to sign in to view your sold products.");
        }
    }
    public void displayBoughtProducts() {
        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();
            List<Product> boughtProducts = currentUser.getProductsBought();

            System.out.println("--- Your Bought Products ---");
            boolean hasBoughtProducts = false;
            for (Product product : boughtProducts) {
                System.out.println(product);
                hasBoughtProducts = true;
            }

            if (!hasBoughtProducts) {
                System.out.println("You have not bought any products yet.");
            }
        } else {
            System.out.println("You need to sign in to view your bought products.");
        }
    }

    public void generateIncomeExpenditureStatement() {
        if (authManager.isAuthenticated()) {
            User currentUser = authManager.getCurrentUser();

            System.out.println("--- Income/Expenditure Statement ---");

            // Calculate income from sold products
            double income = 0.0;
            for (Product product : currentUser.getBoughtProducts()) {
                if (product.isSold()) {
                    income += product.getPrice();
                }
            }

            // Calculate expenditure on bought products
            double expenditure = 0.0;
            for (Product product : currentUser.getProductsPosted()) {
                expenditure += product.getPrice();
            }

            System.out.println("Income: $" + income);
            System.out.println("Expenditure: $" + expenditure);
            System.out.println("Net Profit/Loss: $" + (income - expenditure));
        } else {
            System.out.println("You need to sign in to generate the income/expenditure statement.");
        }
    }
}

