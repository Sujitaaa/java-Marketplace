package FinallProject;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String username;
    private String password;
    private List<Product> productsPosted;
    private List<Product> productsBought;
    private List<Product> productsSold;

    public  User(String username, String password) {
        this.username = username;
        this.password = password;
        this.productsPosted = new ArrayList<>();
        this.productsBought = new ArrayList<>();
        this.productsSold = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public List<Product> getProductsPosted() {
        return productsPosted;
    }

    public List<Product> getProductsBought() {
        return productsBought;
    }

    public List<Product> getProductsSold() {
        return productsSold;
    }

    public void addPostedProduct(Product product) {
        productsPosted.add(product);
    }

    public void addBoughtProduct(Product product) {
        productsBought.add(product);
    }

    public void addSoldProduct(Product product) {
        productsSold.add(product);
    }

    public Product[] getBoughtProducts() {
        return null;
    }
}
