package FinallProject;

public class Product {
    private String title;
    private String description;
    private double price;
    private Category category;
    private User seller;


    private User buyer;
    private boolean isSold;

    public Product(String title, String description, double price, Category category, User seller) {
        this.title = title;
        this.description = description;
        this.price = price;
        this.category = category;
        this.seller = seller;
        this.isSold = false;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public Category getCategory() {
        return category;
    }

    public User getSeller() {
        return seller;
    }

    public User getBuyer() {
        return buyer;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    public boolean isSold() {
        return isSold;
    }

    public void setSold(boolean sold) {
        isSold = sold;
    }


    @Override
    public String toString() {
        return "Title: " + title +
                "\nDescription: " + description +
                "\nPrice: " + price +
                "\nCategory: " + category +
                "\nSeller: " + seller.getUsername() +
                "\nSold: " + isSold;
    }
}