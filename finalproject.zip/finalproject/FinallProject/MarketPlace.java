package FinallProject;

import java.util.Scanner;

public class MarketPlace {
    private AuthenticationManager authManager;
    private MarketPlaceManager marketplaceManager;
    //private DataManager dataManager;

    public MarketPlace() {
        authManager = new AuthenticationManager();
        marketplaceManager = new MarketPlaceManager(authManager);
        //dataManager = new DataManager();
    }

    public void run() {
        boolean isRunning = true;
        boolean isUserSignedIn = false;

        while (isRunning) {
            displayMainMenu();
            int option = getUserChoice();

            switch (option) {
                case 1:
                    authManager.signIn();
                    isUserSignedIn = authManager.isUserSignedIn();
                    break;
                case 2:
                    authManager.signUp();
                    break;
                case 3:
                    authManager.signOut();
                    isUserSignedIn = false;
                    break;
                case 4:
                    if (isUserSignedIn) {
                        marketplaceManager.displayProductListings();
                    }
                    else {
                        System.out.println("You need to sign in to post a product.");
                    }
                    break;
                case 5:
                    if (isUserSignedIn) {
                        marketplaceManager.displayUserProducts();
                    }
                    else {
                        System.out.println("You need to sign in to post a product.");
                    }

                    break;

                case 6:
                    if (isUserSignedIn) {
                        marketplaceManager.filterProductsByCategory();
                    }
                    else {
                        System.out.println("You need to sign in to post a product.");
                    }
                    break;
                case 7:
                    if (isUserSignedIn) {
                        marketplaceManager.postProduct();
                    } else {
                        System.out.println("You need to sign in to post a product.");
                    }
                    break;
                case 8:
                    if (isUserSignedIn) {
                        marketplaceManager.buyProduct();
                    }
                    else {
                    System.out.println("You need to sign in to post a product.");
                }
                    break;
                case 9:
                    if (isUserSignedIn) {
                        marketplaceManager.sellProduct();
                    }
                    else {
                        System.out.println("You need to sign in to post a product.");
                    }
                    break;
                case 10:
                    if (isUserSignedIn) {
                        marketplaceManager.displayBoughtProducts();
                    }
                    else {
                    System.out.println("You need to sign in to post a product.");
                }
                    break;
                case 11:
                    if (isUserSignedIn) {
                        marketplaceManager.displaySoldProducts();
                    }
                    else {
                    System.out.println("You need to sign in to post a product.");
                }
                    break;
                case 12:
                    if (isUserSignedIn) {
                        marketplaceManager.generateIncomeExpenditureStatement();
                    }
                    else {
                    System.out.println("You need to sign in to post a product.");
                }
                    break;
                case 13:
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void displayMainMenu() {
        System.out.println("--- Welcome to the Online Marketplace ---");
        System.out.println("1. Sign In");
        System.out.println("2. Sign Up");
        System.out.println("3. Sign Out");
        if (authManager.isAuthenticated()) {
            System.out.println("4. Display Product List");
            System.out.println("5. Display User Products");
            System.out.println("6. Display Products By Category");
            System.out.println("7. Post Product");
            System.out.println("8. Buy Product");
            System.out.println("9. Sell Product");
            System.out.println("10. Display Bought Products");
            System.out.println("11. Display Sold Products");
            System.out.println("12. Display Income/Expenditure Statement");
        }
        System.out.println("4. Exit");
        System.out.println("-----------------------------------------");
    }


    private int getUserChoice() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your choice: ");
        return scanner.nextInt();
    }

    public static void main(String[] args) {
        MarketPlace marketplace = new MarketPlace();
        marketplace.run();
    }
}
