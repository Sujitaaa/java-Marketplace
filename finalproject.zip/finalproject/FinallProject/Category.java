package FinallProject;

public enum Category {
    ELECTRONICS,
    BOOKS,
    CLOTHING
}
