package FinallProject;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AuthenticationManager {
    private Map<String, User> users;
    private User currentUser;
    private boolean userSignedIn;


    public AuthenticationManager() {
        this.users = new HashMap<>();
        this.currentUser = null;
    }

    public void signUp() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("--- Sign Up ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (users.containsKey(username)) {
            System.out.println("Username already exists. Please choose a different username.");
        } else {
            User newUser = new User(username, password);
            users.put(username, newUser);
            System.out.println("Sign up successful. Please sign in with your new account.");
        }
    }

    public void signIn() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("--- Sign In ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (users.containsKey(username)) {
            User user = users.get(username);
            if (user.getPassword().equals(password)) {
                currentUser = user;
                userSignedIn = true;
                System.out.println("Sign in successful. Welcome, " + username + "!");
                // Perform any additional actions for signed-in user
            } else {
                System.out.println("Invalid password. Please try again.");
            }
        } else {
            System.out.println("Username not found. Please sign up for a new account.");
        }
    }
    public void signOut() {
        currentUser = null;
        userSignedIn = false;
        System.out.println("Logout successful. You have been signed out.");
    }
    public boolean isAuthenticated() {
        return currentUser != null;
    }
    public boolean isUserSignedIn(){
        return userSignedIn;
    }

    public User getCurrentUser() {
        return currentUser;
    }
}
